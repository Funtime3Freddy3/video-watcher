<?php
error_reporting(0);
$path = $_GET['path'];
$type = $_GET['type'];
?>
<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Video Watcher v1.0 - Funtime3Freddy3</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://f3f3.tk/files/css/style.css">
    <style>
    ::-webkit-scroLLbar {
    width: 15px;
    }
    ::-webkit-scroLLbar-track {
    background: #dddddd;
    }
    ::-webkit-scroLLbar-thumb {
    background: #db56fb;
    }
    img {  
        user-drag: none;  
        user-select: none;
        -moz-user-select: none;
        -webkit-user-drag: none;
        -webkit-user-select: none;
        -ms-user-select: none;
    }
    #mouse {
        position: fixed;
        top: 0;
        left: 0;
        width: 10px;
		height: 10px;
		border-radius: 50%;
		background-color: #db56fb;
		color: white;
		text-align: center;
		font-size: 20px;
	}
    </style>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.0/jquery.min.js"></script>
    <script>
      $(document).ready(function() {
          $("body").on("contextmenu", function(e) {
              return false;
            });
        });
    </script>
    <script>  
    $(document).keydown(function (event) {
    if (event.keyCode == 123) { // Prevent F12
        return false;
    }
    });
    </script>  
    <script>
    document.onkeydown = function(e) {
    if (e.ctrlKey && 
        (e.keyCode === 85 )) {
        return false;
        }
    };
    </script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script type="text/javascript">
        function myGeeks() {
            $('img').attr('draggable', false);
        }
    </script>
    <style>
        body {
            margin: 0;
            padding: 0;
        }
        video {
            width: 100vw;
            height: 100vh;
            margin: 0;
            display: block;
            box-sizing: border-box;
    }   
        .title {
            text-align: center;
        }
        .warning {
            text-align: center;
            color: red;
        }
        a[name=link] {
            text-decoration: none;
            color: #db56fb;
        }
        select[name=type] {
            width: 100%;
            border: 16px solid #db56fb;
            border-radius: 25px;
        }
        input[name=path] {
            width: 100%;
            border: 15px solid #db56fb;
            border-radius: 25px;
        }
        input[type=submit] {
            width: 100%;
            background: #db56fb;
            border-radius: 25px;
            transition: 0.5s
        }
        input[type=submit]:hover {
            width: 100%;
            background: red;
            border-radius: 25px;
            transition: 0.5s
        }
    </style>
</head>
<body>
    <?php
    if ($_SERVER['HTTP_HOST'] === 'localhost' || $_SERVER['HTTP_HOST'] === '127.0.0.1') {
        if (strpos($_SERVER['REQUEST_URI'], '/video-watcher') !== false) {
            if($path != NULL && $type != NULL) { ?>
                <style>
                    body {
                        background: black;
                    }
                </style>
                <video controls="controls">
                    <source src="<?php echo $path ?>" type="video/<?php echo $type ?>">
                    Your browser does not support the video tag.
                </video>
                <script>
                    const video = document.querySelector("video");
                    function toggleFullscreen() {
                        if (video.requestFullscreen) {
                            video.requestFullscreen();
                        } else if (video.mozRequestFullScreen) {
                            video.mozRequestFullScreen();
                        } else if (video.webkitRequestFullscreen) {
                            video.webkitRequestFullscreen();
                        } else if (video.msRequestFullscreen) {
                            video.msRequestFullscreen();
                        }
                    }
                    document.addEventListener('keydown', (event) => {
                        if (event.key === 'F' || event.key === 'f') {
                            toggleFullscreen();
                        }
                    });
                </script>
            <?php } elseif($path == NULL && $type == NULL) { ?>
                <div class="container">
                    <h1 class="title">Welcome to Video Watcher version 1.0!A PHP App created and developed by <a name="link" href="https://funtime3freddy3.com" target="_blank">Funtime3Freddy3</a>!</h1>
                    <h1 class="title">Please don't crack movies, videos, music, games, books, etc cuz it's illegal and it's not nice from you.This app was created just to show my developing skills.</h1>
                    <form method="SEARCH">
                        <h3>Video Type:</h3>
                        <select name="type" required>
                            <option value="mp4">MP4</option>
                            <option value="mkv">MKV</option>
                        </select>
                        <h3>Video Path:</h3>
                        <input type="text" name="path" placeholder="Only URLs" required></br>
                        <input type="submit" class="button" value="Watch Video">
                    </form>
                </div>
            <?php }  elseif($path == NULL && $type != NULL) { ?>
                <h1 class="title">Video Type: Yes</h1>
                <h1 class="title">Video Path: No</h1>
                <h3 class="warning">Please put after /movie-watcher/?type=<?php echo $type ?>&path= a video path!</h3>
            <?php }  elseif($path != NULL && $type == NULL) { ?>
                <h1 class="title">Video Type: No</h1>
                <h3 class="warning">Please put before path=<?php echo $path ?> type= and specify a video type!</h3>
                <h1 class="title">Video Path: Yes</h1>
            <?php }
        } else { ?>
            <div class="container">
                <h1 class="title">Sorry!Video Watcher version 1.0 is meant to be used on the path localhost/video-watcher/!Please access it via this link <a name="link" href="http://localhost/video-watcher/">localhost/video-watcher/</a>.</h1>
            </div>
        <?php }
    } else { ?>
        <div class="container">
            <h1 class="title">Sorry!Video Watcher version 1.0 is meant to be used locally!Please access it via this link <a name="link" href="http://localhost/video-watcher/">localhost/video-watcher/</a>.</h1>
        </div>
    <?php } ?>
</body>